function removeAlert(element) {
  element.parentNode.remove();
}

function alertCart() {
  alert("Your cart is empty");
}

function hoverIn(element) {
  element.src = "images/assets/succulents-2.jpg";
}

function hoverOut(element) {
  element.src = "images/assets/succulents-1.jpg";
}
